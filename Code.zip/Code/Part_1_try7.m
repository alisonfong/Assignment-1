xPosition = 200e-9.*rand(1,10);
yPosition = 100e-9.*rand(1,10);
m0 = 9.10938356e-31;                       % in Kg
mi = 0.26*m0;
kb = 1.3806452e-23;                        % in m2 Kg s-2 K-1
Vth = sqrt((kb*300)/mi);                   % Thermal velocity
xVelocity = Vth*randn(1,10);
yVelocity = Vth*randn(1,10);
time = 0.2e-13;
timesteps = 1000;
MFP = Vth*0.2e-12;                         % Mean Free Path 

figure(1)                                  % First Position
plot(xPosition,yPosition,'.');
title("Initial");
grid on;

figure (2)                                 % First Step
plot(xPosition+xVelocity.*time,yPosition+yVelocity.*time,'.');
title("1 step");
grid on;

% tempX = int16.empty(1,0);
% tempY = int16.empty(1,0);

for i = 1:timesteps
    
    % Keep track of the old position
    xPositionPrev = xPosition;
    yPositionPrev = yPosition;
    
%     tempX(i) = mean(xVelocity)
%     tempY(i) = mean(yVelocity)
    
    % Make the new postion
    xPosition = xPositionPrev + xVelocity.*time;
    yPosition = yPositionPrev + yVelocity.*time; 
    
    % Right wrap-around boundary
    ind  = xPosition >  2e-7;
    xPosition(ind) = xPosition(ind) - 2e-7;
    xPositionPrev(ind) = xPositionPrev(ind) - 2e-7; 

    % Left wrap-around boundary
    ind2 = xPosition<0;
    xPosition(ind2) = xPosition(ind2) + 2e-7;
    xPositionPrev(ind2) = xPositionPrev(ind2) + 2e-7;
   
    % Top reflection boundary
    ind3 = yPosition > 100e-9;
    yVelocity(ind3) = yVelocity(ind3) * (-1); 
    yPosition(ind3) = yPositionPrev(ind3) + yVelocity(ind3).*time; 

    % Bottom reflection boundary
    ind4 = yPosition < 0;
    yVelocity(ind4) = yVelocity (ind4)* (-1); 
    yPosition(ind4) = yPositionPrev(ind4) + yVelocity(ind4).*time; 
    
    % Create model movie
    figure(3)
    set(gca,'ColorOrder',[0 0 1;0 1 0;0 1 1;1 0 0;1 0 1;1 1 0;0.5 0.5 0.5;0.4 0.7 0.2; 0.3 0.4 0.9;0.1 0.2 0.1]);
    plot([xPositionPrev.', xPosition.'].',[yPositionPrev.', yPosition.'].');
    axis([0 200e-9 0 100e-9]);
    grid on;
    hold on;
    
    
% Attempt at plotting the temperature plot    
%     figure(4)
%     ax1 = subplot(2,1,1);
%     plot(ax1,time*i,tempX,'r');
%     grid on;
%     hold on;
%     
%     ax2 = subplot(2,1,2);
%     plot(ax2,time*i,tempY,'b');
%     grid on;
%     hold on;
end   